# nav2_teb_controller

A modern C++20 reimplementation of the **classic (discrete) Timed Elastic Band (TEB)** local planner for
[Nav2](https://nav2.org/) (tested on ROS 2 Humble and Jazzy). The trajectory is a band of SE(2) poses with time steps (Δt);
velocities and higher derivatives are computed by finite differences. The band is deformed by **sparse
nonlinear least-squares optimization** (`libg2o`, Gauss-Newton / Levenberg-Marquardt) considering kinematics,
dynamics, obstacle avoidance, and execution time.

Based on the original [`teb_local_planner`](https://github.com/rst-tu-dortmund/teb_local_planner) by
RST – TU Dortmund, redesigned for ROS 2 with ESDF-based obstacle avoidance.

> **Documentation (start here)**
> - [`doc/architecture.md`](doc/architecture.md) — system architecture, modules, control-loop data flow (diagrams)
> - [`doc/control_concept.md`](doc/control_concept.md) — TEB theory, g2o graph formulation, per-edge math, control law
> - [`doc/parameters.md`](doc/parameters.md) — full parameter reference (**auto-generated** from
>   `config/teb_controller_parameters.yaml` via `make docs`; edit the schema, not the doc)
> - [`doc/status.md`](doc/status.md) — status & roadmap (implemented / planned features), gotchas & traps
> - [`AGENTS.md`](AGENTS.md) — developer cheat-sheet (structure, references to the docs above)

## Features

- **Trajectory optimization via g2o** — Gauss-Newton or Levenberg-Marquardt, 4 solver backends (eigen, cholmod,
  csparse, dense)
- **27 custom g2o edge classes** (22 wired into the graph) — velocity, acceleration, jerk, snap, kinematics
  (diff-drive + car-like), steering rate/angle, G³ continuity, time-optimal, shortest path, path smoothness,
  ESDF obstacles
- **ESDF obstacle avoidance** — Meijster O(n) Euclidean Distance Transform, bilinear interpolation + analytical
  gradients, per-footprint-circle soft constraints with robust kernel
- **Footprint-aware collision checking** — circle model (polygon → circles), hard feasibility stop
- **3-phase stepwise optimization** — obstacles+kinematics → kinodynamics → efficiency objectives
- **Robot models** — `diff_drive`, `skid_steer` (soft body-slip constraint, controlled reverse) and
  `ackermann` (turning radius, steering rate, steering feedback from `/tricycle_state`); holonomic mode by
  `v_max_y > 0`
- **Dynamic parameter reconfiguration** via `generate_parameter_library`
- **RViz visualization** — 7 topics: local plan, lookahead, poses, obstacles, curvature radii, footprint

## Videos

| New TEB RViz<br/>[<img src="https://img.youtube.com/vi/BqfFwOXZO0k/hqdefault.jpg" width="240" alt="New TEB RViz"/>](https://www.youtube.com/watch?v=BqfFwOXZO0k) | New TEB RViz obstacles<br/>[<img src="https://img.youtube.com/vi/a3creSJZxis/hqdefault.jpg" width="240" alt="New TEB RViz obstacles"/>](https://www.youtube.com/watch?v=a3creSJZxis) | New TEB RViz loose goal<br/>[<img src="https://img.youtube.com/vi/3201fSL2xvI/hqdefault.jpg" width="240" alt="New TEB RViz loose goal"/>](https://www.youtube.com/watch?v=3201fSL2xvI) |
|:---:|:---:|:---:|

## Status

The detailed status & roadmap (with gotchas) lives in [`doc/status.md`](doc/status.md). In short:

**Implemented**
- TEBController plugin lifecycle + Nav2 controller API (`setPlan`, `computeVelocityCommands`, `setSpeedLimit`)
- g2o trajectory optimization: 3-phase stepwise, 27 edge classes (22 wired), 2 vertex types, `addEdgesGeneric` factory
- Global-path reference edges keep the optimized band on the current plan and reset warm starts on material same-goal replans
- ESDF obstacle avoidance (Meijster EDT, gradients, per-footprint-circle soft constraints)
- Footprint collision check (circle model), hard feasibility stop
- TEB utilities: init, autoResize, prune, velocity extraction, Ackermann↔Twist conversion, saturation
- Robot models: `diff_drive`, `skid_steer`, `ackermann` (steering feedback via `/tricycle_state`);
  holonomic by `v_max_y > 0`
- Parameters via `generate_parameter_library`, RViz visualization (7 topics), gtest unit tests

**Planned / not yet implemented**
- Homotopy Class Planning (interfaces only, `plan()` is a stub) — keep `hcp.activate: false`
- Preferred rotation direction and legacy obstacle association (edges not wired)
- ESDF-aware autoResize, recovery behaviors, integration tests (`test/integration/` empty)
- TEB-K (cubic Hermite spline segments) — research feature, not implemented

## Quick Start

Extract or copy this package into a ROS 2 workspace, then install its declared dependencies and build it:

```bash
mkdir -p ~/ros2_ws/src
tar -xzf nav2_teb_controller-0.2.0-source.tar.gz -C ~/ros2_ws/src
cd ~/ros2_ws
sudo apt update
sudo apt install python3-rosdep python3-vcstool
vcs import src < src/nav2_teb_controller/nav2_teb_controller.repos
rosdep install --from-paths src --ignore-src -r -y --rosdistro "${ROS_DISTRO:-humble}"
colcon build --packages-up-to nav2_teb_controller --cmake-args -DCMAKE_BUILD_TYPE=Release
source install/setup.bash
```

The optimizer requires g2o with its CMake package files. If g2o is installed in a custom prefix, export it before
building and at runtime:

```bash
export CMAKE_PREFIX_PATH=/path/to/g2o-install:${CMAKE_PREFIX_PATH:-}
export LD_LIBRARY_PATH=/path/to/g2o-install/lib:${LD_LIBRARY_PATH:-}
```

## Configuration

Add to Nav2 params:

```yaml
controller_server:
  ros__parameters:
    controller_plugins: ["FollowPath"]
    FollowPath:
      plugin: "nav2_teb_controller::TEBController"
      # ... see config/teb_controller_params.yaml for a complete tuned example
```

Key defaults to be aware of (see `doc/parameters.md`):
- `hcp.activate` must stay `false` (homotopy planning not implemented).
- `robot_model` ∈ {`diff_drive`, `skid_steer`, `ackermann`} (`"bicycle"` was removed from the schema).
- `v_max_y > 0` switches the planner to holonomic (default schema value is `0.5` — set `0.0` for non-holonomic).

For a four-wheel skid-steer Jackal, merge
[`config/jackal_skid_steer_1p2.yaml`](config/jackal_skid_steer_1p2.yaml) into the Nav2 parameter file. It provides
the tested 1.2 m/s forward-speed limit, 2.5 m global-plan lookahead, turn-first/forward-preferred route tracking,
controlled reverse escape, matching velocity-smoother limits and the two-circle footprint.

## Tests

```bash
make test                    # all tests
colcon test --packages-select nav2_teb_controller \
  --event-handlers console_direct+ \
  --ctest-args -R test_edge_time_optimal  # single test
```

## Parameter Documentation

`doc/parameters.md` is **generated** from the parameter schema
[`config/teb_controller_parameters.yaml`](config/teb_controller_parameters.yaml) (the single source of truth —
also used by `generate_parameter_library` at build time and shown at runtime by `ros2 param describe`):

```bash
make docs          # regenerate doc/parameters.md
make docs-check    # fail if doc/parameters.md is out of date (CI)
```

Never edit `doc/parameters.md` by hand — change the schema descriptions instead.

## References

- C. Rösmann, W. Feiten, T. Wösch, F. Hoffmann, T. Bertram: *Trajectory modification considering dynamic constraints of autonomous robots*, ROBOTIK 2012.
- C. Rösmann, F. Hoffmann, T. Bertram: *Integrated online trajectory planning and optimization in distinctive topologies*, RAS 2017.

## License

BSD 3-Clause. See LICENSE.
