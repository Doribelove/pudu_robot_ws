#include <gtest/gtest.h>

#include <Eigen/Core>

#include "nav2_teb_controller/g2o_types/edge_via_point.h"
#include "nav2_teb_controller/g2o_types/vertex_pose.h"
#include "test_jacobian_utils.hpp"

using namespace nav2_teb_controller;

TEST(EdgeViaPoint, ComputesDistanceToReferencePoint) {
  EdgeViaPoint edge;
  VertexPose vertex;
  vertex.setEstimate(PoseSE2(4.0, 6.0, 0.7));
  const Eigen::Vector2d via_point(1.0, 2.0);

  edge.setVertex(0, &vertex);
  edge.setViaPoint(&via_point);
  edge.computeError();

  EXPECT_NEAR(edge.error()[0], 5.0, 1e-12);
}

TEST(EdgeViaPoint, JacobianMatchesNumeric) {
  EdgeViaPoint edge;
  VertexPose vertex;
  vertex.setEstimate(PoseSE2(2.4, -0.8, 0.3));
  const Eigen::Vector2d via_point(0.2, 1.1);

  edge.setVertex(0, &vertex);
  edge.setViaPoint(&via_point);
  edge.computeError();

  expectAnalyticJacobianMatchesNumericUnary(edge);
}

int main(int argc, char **argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
