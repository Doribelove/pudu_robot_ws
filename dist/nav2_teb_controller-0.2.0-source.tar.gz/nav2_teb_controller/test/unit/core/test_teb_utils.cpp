#include <angles/angles.h>
#include <gtest/gtest.h>

#include <geometry_msgs/msg/twist.hpp>
#include <nav_msgs/msg/path.hpp>

#include "nav2_teb_controller/core/teb_utils.hpp"

namespace nav2_teb_controller {
namespace {

nav_msgs::msg::Path makeBackOutThenForwardPath() {
  nav_msgs::msg::Path path;
  path.header.frame_id = "map";
  for (const double x : {0.0, -0.5, -1.0, 1.0}) {
    geometry_msgs::msg::PoseStamped pose;
    pose.pose.position.x = x;
    pose.pose.orientation.w = 1.0;
    path.poses.push_back(pose);
  }
  return path;
}

TEST(TebUtils, BackwardInitializationUsesFirstPathSegment) {
  TimedElasticBand teb;

  ASSERT_TRUE(initFromPath(teb, makeBackOutThenForwardPath(), 1.0, 1.8, true, 3, true, true));
  ASSERT_GE(teb.sizePoses(), 3u);

  // The local goal is in front (+x), but the first path segment is behind.
  // A skid-steer back-out keeps its body facing +x instead of turning around.
  EXPECT_NEAR(angles::normalize_angle(teb.pose(1).theta()), 0.0, 1e-9);
  const geometry_msgs::msg::Twist cmd = getVelocityCommand(teb, 0.3, 1, 0.0, false);
  EXPECT_LT(cmd.linear.x, 0.0);
  EXPECT_NEAR(cmd.angular.z, 0.0, 1e-9);
}

TEST(TebUtils, ReverseSaturationPreservesCurvatureRatio) {
  geometry_msgs::msg::Twist cmd;
  cmd.linear.x = -0.8;
  cmd.angular.z = 1.0;

  saturateVelocity(cmd, 1.0, 0.0, 1.8, 0.4, true);

  EXPECT_NEAR(cmd.linear.x, -0.4, 1e-12);
  EXPECT_NEAR(cmd.angular.z, 0.5, 1e-12);
}

}  // namespace
}  // namespace nav2_teb_controller

int main(int argc, char **argv) {
  testing::InitGoogleTest(&argc, argv);
  return RUN_ALL_TESTS();
}
