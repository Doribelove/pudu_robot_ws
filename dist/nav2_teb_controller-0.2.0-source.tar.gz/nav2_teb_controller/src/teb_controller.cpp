#include "nav2_teb_controller/teb_controller.hpp"

#include <tf2/time.h>

#include <algorithm>
#include <cmath>
#include <limits>
#include <memory>

#include "nav2_teb_controller/teb_profiler.hpp"

namespace nav2_teb_controller {

namespace {

double squaredDistanceToPath(const geometry_msgs::msg::Point &query,
                             const nav_msgs::msg::Path &path) {
  if (path.poses.empty())
    return std::numeric_limits<double>::max();
  if (path.poses.size() == 1) {
    const double dx = query.x - path.poses.front().pose.position.x;
    const double dy = query.y - path.poses.front().pose.position.y;
    return dx * dx + dy * dy;
  }

  double min_squared_distance = std::numeric_limits<double>::max();
  for (std::size_t i = 1; i < path.poses.size(); ++i) {
    const auto &start = path.poses[i - 1].pose.position;
    const auto &end = path.poses[i].pose.position;
    const double segment_x = end.x - start.x;
    const double segment_y = end.y - start.y;
    const double squared_length = segment_x * segment_x + segment_y * segment_y;
    const double interpolation =
        squared_length > 1e-12
            ? std::clamp(((query.x - start.x) * segment_x + (query.y - start.y) * segment_y) /
                             squared_length,
                         0.0, 1.0)
            : 0.0;
    const double dx = query.x - (start.x + interpolation * segment_x);
    const double dy = query.y - (start.y + interpolation * segment_y);
    min_squared_distance = std::min(min_squared_distance, dx * dx + dy * dy);
  }
  return min_squared_distance;
}

double maximumPathDeviation(const nav_msgs::msg::Path &new_path,
                            const nav_msgs::msg::Path &old_path) {
  double max_squared_deviation = 0.0;
  for (const auto &pose : new_path.poses) {
    max_squared_deviation =
        std::max(max_squared_deviation, squaredDistanceToPath(pose.pose.position, old_path));
  }
  return std::sqrt(max_squared_deviation);
}

}  // namespace

void TEBController::configure(const rclcpp_lifecycle::LifecycleNode::WeakPtr &parent,
                              std::string name, std::shared_ptr<tf2_ros::Buffer> tf,
                              std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) {
  node_ = parent;
  plugin_name_ = name;
  tf_ = tf;
  costmap_ros_ = costmap_ros;

  auto node = node_.lock();
  if (!node) {
    throw std::runtime_error("TEBController: failed to lock node in configure()");
  }

  logger_ = node->get_logger();
  clock_ = node->get_clock();

  // Declare + load all parameters via generated ParamListener
  param_listener_ =
      std::make_shared<teb_controller::ParamListener>(node->get_node_parameters_interface());
  params_ = param_listener_->get_params();

  // String → Level mappen
  const std::string log_level_str = params_.FollowPath.log_level;
  const std::map<std::string, rclcpp::Logger::Level> level_map = {
      {"debug", rclcpp::Logger::Level::Debug}, {"info", rclcpp::Logger::Level::Info},
      {"warn", rclcpp::Logger::Level::Warn},   {"error", rclcpp::Logger::Level::Error},
      {"fatal", rclcpp::Logger::Level::Fatal},
  };
  const auto level = level_map.contains(log_level_str) ? level_map.at(log_level_str)
                                                       : rclcpp::Logger::Level::Info;
  logger_.set_level(level);
  rclcpp::get_logger("optimal_planner").set_level(level);

  // Tricycle steering angle subscription
  tricycle_state_sub_ = node->create_subscription<ackermann_msgs::msg::AckermannDriveStamped>(
      "/tricycle_state", rclcpp::QoS(1).best_effort(),
      [this](const ackermann_msgs::msg::AckermannDriveStamped::SharedPtr msg) {
        last_ackermann_cmd_ = *msg;
      });

  // All sub-systems take const ref into params_.FollowPath — no copying
  // Footprint
  bool use_local_costmap = params_.FollowPath.robot.footprint.use_local_costmap;
  std::string model = params_.FollowPath.robot.footprint.model;
  std::string points = params_.FollowPath.robot.footprint.points;
  footprint_ = Footprint(use_local_costmap, model, points);
  RCLCPP_INFO(logger_, "%s", footprint_.toString().c_str());
  // ESDF
  const double esdf_hz = params_.FollowPath.obstacles.costmap_converter_rate;
  esdf_update_period_ = rclcpp::Duration::from_seconds(1.0 / esdf_hz);
  // Visualization
  const double visu_hz = params_.FollowPath.visualization.publish_rate;
  visualize_update_period_ = rclcpp::Duration::from_seconds(1.0 / visu_hz);
  // Planner
  if (params_.FollowPath.hcp.activate) {
    RCLCPP_ERROR(logger_,
                 "TEBController: Homotopy class planning is NOT implemented yet. "
                 "Disable 'hcp.activate' — falling back to direct planner is not possible either, "
                 "the HCP placeholder will fail at plan() time.");
    auto p = std::make_shared<DiscreteTEBPlanner>(params_, footprint_, costmap_ros_.get());
    auto gs = std::make_shared<VisibilityGraphSearch>(0.5, 0.5);  // inflation_radius, robot_radius
    auto hcp = std::make_unique<HomotopyClassPlanner>(params_, footprint_, costmap_ros_.get());
    hcp->setBasePlanner(p);
    hcp->setGraphSearch(gs);
    hcp->setObstacleMap(&esdf_);
    teb_planner_ = hcp.get();   // PlannerInterface
    planner_ = std::move(hcp);  // PlannerBase
  } else {
    auto p = std::make_unique<DiscreteTEBPlanner>(params_, footprint_, costmap_ros_.get());
    p->setObstacleMap(&esdf_);
    teb_planner_ = p.get();   // PlannerInterface
    planner_ = std::move(p);  // PlannerBase
  }
  // Visu
  visualizer_ = std::make_unique<TEBVisualizer>(node);
  visualizer_->on_configure();
}

void TEBController::activate() {
  visualizer_->on_activate();
  RCLCPP_INFO(logger_, "TEBController activated");
}

void TEBController::deactivate() {
  RCLCPP_INFO(logger_, "TEBController deactivated");
}

void TEBController::cleanup() {
  RCLCPP_INFO(logger_, "TEBController cleaned up");
}

void TEBController::setPlan(const nav_msgs::msg::Path &path) {
  bool reset = global_plan_.poses.empty() || path.poses.empty();
  if (!reset) {
    const auto &old_goal = global_plan_.poses.back().pose.position;
    const auto &new_goal = path.poses.back().pose.position;
    const double dx = old_goal.x - new_goal.x;
    const double dy = old_goal.y - new_goal.y;
    // Nav2's replanning behavior republishes an equivalent path frequently.
    // Preserve the TEB warm start for those updates; only a materially changed
    // goal or frame requires a cold restart.
    const double path_deviation = maximumPathDeviation(path, global_plan_);
    reset = (dx * dx + dy * dy) > 0.25 ||
            path_deviation > params_.FollowPath.trajectory.reinit_path_dist ||
            global_plan_.header.frame_id != path.header.frame_id;
  }
  global_plan_ = path;
  if (reset)
    planner_->clear();
  RCLCPP_INFO(logger_, "New global plan received (%zu poses)", path.poses.size());
  RCLCPP_INFO(logger_, "%s", reset ? "Reset TEB trajectory." : "Keep TEB warm start.");
}

geometry_msgs::msg::TwistStamped TEBController::computeVelocityCommands(
    const geometry_msgs::msg::PoseStamped &pose, const geometry_msgs::msg::Twist &velocity,
    nav2_core::GoalChecker * /*goal_checker*/) {
  geometry_msgs::msg::TwistStamped cmd_vel;
  cmd_vel.header.stamp = clock_->now();
  cmd_vel.header.frame_id = costmap_ros_->getGlobalFrameID();
  auto goal_pose = global_plan_.poses.back();
  // Report the completed profiling window at the top of the next tick so that every
  // block (including "total") of all 100 ticks has been fully recorded (off-by-one fix:
  // previously the report fired while the current tick's "total" block was still alive).
  {
    const std::string profile_report = PROFILE_REPORT();
    if (!profile_report.empty()) {
      RCLCPP_INFO(logger_, "[PROFILE]\n%s", profile_report.c_str());
    }
  }
  PROFILE_TICK();
  PROFILE_BLOCK("total");

  // 1. Refresh dynamic parameters
  if (param_listener_->is_old(params_))
    params_ = param_listener_->get_params();  // later, needs_full_rebuild_ = true;

  // 2. Extract local lookahead window
  // prune global plan to cut off parts of the past (spatially before the robot)
  const double prune_dist = params_.FollowPath.trajectory.global_plan_prune_distance;
  const double path_length = params_.FollowPath.trajectory.max_global_plan_lookahead_dist;
  int goal_idx;
  nav_msgs::msg::Path transformed_plan;
  {
    PROFILE_BLOCK("prune_trim");
    // Single latest-known transform lookup (plan frame → global frame). The previous
    // stamped-time lookup (plan stamp) blocked up to its 0.5 s timeout whenever the
    // exact stamped transform was not cached yet — the source of single-tick 10 ms
    // prune_trim spikes. TimePointZero uses the newest available transform; the plan
    // frame is quasi-static, so this is equivalent except that it never blocks.
    const std::string plan_frame = global_plan_.poses.front().header.frame_id;
    try {
      const geometry_msgs::msg::TransformStamped plan_to_global_stamped =
          tf_->lookupTransform(costmap_ros_->getGlobalFrameID(), plan_frame, tf2::TimePointZero);
      // Manual construction: tf2::fromMsg/toMsg templates don't match the
      // allocator-parameterized rosidl types on all rmw configurations.
      const auto &t = plan_to_global_stamped.transform;
      const tf2::Transform plan_to_global(
          tf2::Quaternion(t.rotation.x, t.rotation.y, t.rotation.z, t.rotation.w),
          tf2::Vector3(t.translation.x, t.translation.y, t.translation.z));
      pruneGlobalPlan(plan_to_global, pose, global_plan_, prune_dist);
      transformed_plan = transformAndTrimPlan(
          plan_to_global, global_plan_, pose, *costmap_ros_->getCostmap(),
          costmap_ros_->getGlobalFrameID(), clock_->now(), path_length, &goal_idx);
    } catch (const tf2::TransformException &ex) {
      RCLCPP_DEBUG(logger_, "TF transform failed: %s", ex.what());
    }

    if (transformed_plan.poses.empty()) {
      RCLCPP_INFO(logger_, "TEBController: Empty plan.");
      return cmd_vel;
    }
    // Overwrite start with actual robot pose so TEB can use plan as initial trajectory
    if (transformed_plan.poses.size() == 1)  // plan only contains the goal
      transformed_plan.poses.insert(transformed_plan.poses.begin(),
                                    geometry_msgs::msg::PoseStamped());
    transformed_plan.poses.front() = pose;
  }

  // Update obstacles
  costmap_converter_msgs::msg::ObstacleArrayMsg::ConstSharedPtr obstacles_ptr;
  {
    PROFILE_BLOCK("obstacles");
    // nullptr selects DiscreteTEBPlanner::extractObstacles(), which reads the
    // live Nav2 Costmap2D directly and avoids the legacy converter plugin.
    teb_planner_->updateObstacleContainer(obstacles_ptr);
  }
  // Update ESDF
  {
    PROFILE_BLOCK("esdf_update");
    const rclcpp::Time now = clock_->now();
    if ((now - last_esdf_update_) >= esdf_update_period_) {
      std::unique_lock lock(*costmap_ros_->getCostmap()->getMutex());
      esdf_.update(*costmap_ros_->getCostmap());
      last_esdf_update_ = now;
    }
  }

  // update via-points container
  // updateViaPointsContainer(transformed_plan, cfg_->trajectory.global_plan_viapoint_sep);

  // check if we should enter any backup mode and apply settings
  // configureBackupModes(transformed_plan, goal_idx);

  // 3. Plan, wart start or reinit
  bool success;
  {
    PROFILE_BLOCK("planner_plan");
    bool final_goal = (goal_idx == ((int)global_plan_.poses.size() - 1)) ||
                      params_.FollowPath.optimizer.fix_goal;
    teb_planner_->setFixedGoal(final_goal);
    teb_planner_->setFeedback(last_ackermann_cmd_.drive);
    success = planner_->plan(transformed_plan, velocity);
  }
  if (!success || planner_->hasDiverged()) {
    planner_->clear();
    RCLCPP_INFO(logger_, "TEBController: Planner failed.");
    return cmd_vel;
  }

  // 4. Get TEB
  const auto &teb = teb_planner_->getTEB();

  // 5. Check for collision
  int index;
  {
    PROFILE_BLOCK("feasibility");
    const double feasibility_check = params_.FollowPath.obstacles.feasibility_check;
    index = checkFeasibility(teb, esdf_, footprint_, feasibility_check);
  }
  const bool stop_cmd = index >= 0;

  // 5. Visualize (throttled to the configured publish rate)
  {
    PROFILE_BLOCK("visualize");
    const rclcpp::Time now = clock_->now();
    if ((now - last_visualize_time_) >= visualize_update_period_) {
      last_visualize_time_ = now;
      const std::string frame_id = costmap_ros_->getGlobalFrameID();
      visualizer_->publishLocalPlan(teb, frame_id);
      visualizer_->publishLookaheadPlan(transformed_plan);
      visualizer_->publishTEBPoses(teb, frame_id);
      visualizer_->publishObstacles(obstacles_ptr, frame_id);
      visualizer_->publishCurvatureRadii(teb, frame_id);
      visualizer_->publishFootprint(teb.pose(std::max(index, 0)), footprint_, frame_id);
    }
  }

  // 6. Get velocity command
  {
    PROFILE_BLOCK("velocity_output");
    const bool activate = params_.FollowPath.path_tracker.activate;
    if (activate && !stop_cmd) {
      const double dt_ref = params_.FollowPath.trajectory.dt_ref;
      const int lookahead = params_.FollowPath.trajectory.control_look_ahead_poses;
      const double min_look_ahead_time = params_.FollowPath.trajectory.control_min_look_ahead_time;
      cmd_vel.twist = getVelocityCommand(teb, dt_ref, lookahead, min_look_ahead_time, false);

      // Saturate velocity
      double limit_ratio = 1.0;
      if (speed_limit_ != nav2_costmap_2d::NO_SPEED_LIMIT) {
        if (speed_limit_is_percentage_) {
          limit_ratio = speed_limit_ / 100.0;
        } else if (params_.FollowPath.robot.v_max_x > 1e-12) {
          limit_ratio = speed_limit_ / params_.FollowPath.robot.v_max_x;
        }
        limit_ratio = std::clamp(limit_ratio, 0.0, 1.0);
      }
      const double v_max_x = params_.FollowPath.robot.v_max_x * limit_ratio;
      const double v_max_y = params_.FollowPath.robot.v_max_y * limit_ratio;
      const double v_max_theta = params_.FollowPath.robot.v_max_theta * limit_ratio;
      const double v_max_x_backwards = params_.FollowPath.robot.v_max_x_backwards * limit_ratio;
      const double steering_rate_max = params_.FollowPath.robot.steering_rate_max;
      const double wheelbase = params_.FollowPath.robot.wheelbase;
      const bool use_proportional_saturation =
          params_.FollowPath.robot.use_proportional_saturation;
      double current_angle = last_ackermann_cmd_.drive.steering_angle;
      saturateVelocity(cmd_vel.twist, v_max_x, v_max_y, v_max_theta, v_max_x_backwards,
                       use_proportional_saturation);
      // Saturate steering angle
      auto dt = (clock_->now() - last_cmd_vel_.header.stamp).nanoseconds() / 1e9;
      saturateSteeringAngle(cmd_vel.twist, current_angle, steering_rate_max, wheelbase, dt);
    }
    last_cmd_vel_ = cmd_vel;
  }

  return cmd_vel;
}

void TEBController::setSpeedLimit(const double &speed_limit, const bool &percentage) {
  speed_limit_ = speed_limit;
  speed_limit_is_percentage_ = percentage;

  RCLCPP_DEBUG(logger_, "TEBController speed limit set to %.2f (%s)", speed_limit_,
               speed_limit_is_percentage_ ? "percentage" : "absolute");
}

}  // namespace nav2_teb_controller
